﻿public interface ISortable
{
    void Sort(int[] array);
}
